sap.ui.define([
	"ZBethyl/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox",
	"sap/ui/model/Sorter",
	"../Formatter"
], function(BaseController, History, JSONModel, MessageToast, Filter, FilterOperator, MessageBox, Sorter, Formatter) {
	"use strict";

	return BaseController.extend("ZBethyl.controller.ServiceOrders", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZBethyl.view.ServiceOrders
		 */
		onInit: function() {
			//create model for some static data
			var model = new sap.ui.model.json.JSONModel({
				"SOList": [{
						"soNo": "SO111111",
						"soName": "SalesOrder 1",
						"soDesc": "SalesOrder Description 1",
						"soPrice": "10",
						"soPriceUnit": "$",
						"soStatus": "Not Started",
						"soDate": "04/05/2019"
					}, {
						"soNo": "SO111112",
						"soName": "SalesOrder 2",
						"soDesc": "SalesOrder Description 2",
						"soPrice": "20",
						"soPriceUnit": "$",
						"soStatus": "Completed",
						"soDate": "05/05/2019"
					}, {
						"soNo": "SO111113",
						"soName": "SalesOrder 3",
						"soDesc": "SalesOrder Description 3",
						"soPrice": "30",
						"soPriceUnit": "$",
						"soStatus": "In Progress",
						"soDate": "06/05/2019"
					}, {
						"soNo": "SO111114",
						"soName": "SalesOrder 4",
						"soDesc": "SalesOrder Description 4",
						"soPrice": "40",
						"soPriceUnit": "$",
						"soStatus": "Completed",
						"soDate": "06/05/2019"
					}, {
						"soNo": "SO111115",
						"soName": "SalesOrder 5",
						"soDesc": "SalesOrder Description 5",
						"soPrice": "50",
						"soPriceUnit": "$",
						"soStatus": "Not Started",
						"soDate": "07/05/2019"
					}, {
						"soNo": "SO111116",
						"soName": "SalesOrder 6",
						"soDesc": "SalesOrder Description 6",
						"soPrice": "60",
						"soPriceUnit": "$",
						"soStatus": "In Progress",
						"soDate": "08/05/2019"
					}

				]
			});

			this.getView().setModel(model);
		},
		
		formatstatus :  function (sStatus) {
				if (sStatus === "Completed") {
					return "Success";
				} else if (sStatus === "In Progress") {
					return "Warning";
				} else if (sStatus === "Not Started"){
					return "Error";
				} else {
					return "None";
				}
		},

		onLiveSearch: function(oEvent) {

			//live search handler
			var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("soNo", sap.ui.model.FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			//update bindings
			var list = this.byId("idSOList");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		handleSortButtonPressed: function() {
			//sort button handler
			this._createSortsDialog("ZBethyl.view.sortDialog").open();
		},

		_createSortsDialog: function(sDialogFragmentName) {
			//create sort dialog
			if (!this._oSortDialog) {
				// create dialog via fragment factory
				this._oSortDialog = sap.ui.xmlfragment(this.getView().getId(), sDialogFragmentName, this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._oSortDialog);
			}
			return this._oSortDialog;
		},

		handleSortDialogConfirm: function(oEvent) {
			//sort dialog confirm
			var oList = this.byId("idSOList"),
				mParams = oEvent.getParameters(),
				oBinding = oList.getBinding("items"),
				sPath,
				bDescending,
				aSorters = [];
			sPath = mParams.sortItem.getKey();
			bDescending = mParams.sortDescending;
			aSorters.push(new Sorter(sPath, bDescending));
			// apply the selected sort and group settings
			oBinding.sort(aSorters);
		},

		onFilterSearch: function(oEven) {
			//Filter Search handler
			var inSoNo = this.getView().byId("idSONo").getValue();
			var inSODate = this.getView().byId("idSODate").getValue();
			var inSOPrice = this.getView().byId("idSOPrice").getValue();
			var inSOStatus = this.getView().byId("idSOStatus").getSelectedKey();

			var aFilters = [];

			if (inSoNo && inSoNo.length > 0) {
				var inSoNoFilter = new Filter("soNo", sap.ui.model.FilterOperator.Contains, inSoNo);
				aFilters.push(inSoNoFilter);
			}
			if (inSODate && inSODate.length > 0) {
				var inSODateFilter = new Filter("soDate", sap.ui.model.FilterOperator.Contains, inSODate);
				aFilters.push(inSODateFilter);
			}
			if (inSOPrice && inSOPrice.length > 0) {
				var inSOPriceFilter = new Filter("soPrice", sap.ui.model.FilterOperator.Contains, inSOPrice);
				aFilters.push(inSOPriceFilter);
			}
			if (inSOStatus && inSOStatus.length > 0) {
				var inSOStatusFilter = new Filter("soStatus", sap.ui.model.FilterOperator.Contains, inSOStatus);
				aFilters.push(inSOStatusFilter);
			}
			//update bindings
			var list = this.byId("idSOList");
			var binding = list.getBinding("items");
			binding.filter(aFilters, "Application");
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator;

			// if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZBethyl.view.ServiceOrders
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZBethyl.view.ServiceOrders
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZBethyl.view.ServiceOrders
		 */
		//	onExit: function() {
		//
		//	}

	});

});