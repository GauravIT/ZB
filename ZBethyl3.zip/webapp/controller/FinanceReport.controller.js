sap.ui.define([
	"ZBethyl/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(BaseController, History, JSONModel, MessageToast, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("ZBethyl.controller.FinanceReport", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZBethyl.view.FinanceReport
		 */
		onInit: function() {
			//create model for some static data
			this.model = new sap.ui.model.json.JSONModel({
				"Sale": [{
					"month": "Jan, 2019",
					"revenue": "1456777785"
				}, {
					"month": "Feb, 2019",
					"revenue": "2456864789"
				}, {
					"month": "March, 2019",
					"revenue": "2456664889"
				},{
					"month": "April, 2019",
					"revenue": "5456692887"
				},{
					"month": "May, 2019",
					"revenue": "6452944881"
				}]
			});
			
			//pie chart setting
			this._configureChart(this.getView().byId("idPieVizFrame"), "Pie Chart");
			//donut char setting
			this._configureChart(this.getView().byId("idDonutVizFrame"), "Donut Chart");
			//column chart setting
			this._configureChart(this.getView().byId("idColumnVizFrame"), "Column Chart");
			//line chart setting
			this._configureChart(this.getView().byId("idLineVizFrame"), "Line Chart");
			//bar chart setting
			this._configureChart(this.getView().byId("idBarVizFrame"), "Bar Chart");

			//set model for table
			var oChartTable = this.getView().byId("idChartTable");
			oChartTable.setModel(this.model);
		},
		
		_configureChart: function(oVizFrame, chartName){
			//configure chart
			oVizFrame.setModel(this.model);
			oVizFrame.setVizProperties({
				plotArea: {
					colorPalette: d3.scale.category20().range(),
					dataLabel: {
						showTotal: true
					}
				},
				tooltip: {
					visible: true
				},
				title: {
					text: chartName
				}
			});
		},
		
		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator;

			// if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZBethyl.view.FinanceReport
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZBethyl.view.FinanceReport
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZBethyl.view.FinanceReport
		 */
		//	onExit: function() {
		//
		//	}

	});

});