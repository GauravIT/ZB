sap.ui.define([
	"ZBethyl/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("ZBethyl.controller.App", {

		onInit: function () {

		}

	});

});