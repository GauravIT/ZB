sap.ui.define([
	"ZBethyl/controller/BaseController",
	"sap/ui/core/routing/History",
	"sap/ui/model/json/JSONModel",
	"sap/m/MessageToast",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/MessageBox"
], function(BaseController, History, JSONModel, MessageToast, Filter, FilterOperator, MessageBox) {
	"use strict";

	return BaseController.extend("ZBethyl.controller.EquipmentHistory", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf ZBethyl.view.EquipmentHistory
		 */
		onInit: function() {
			// var jsonData = {
			// 	"Tasks": [{
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review article",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Vikrant Patil",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review and Approve article - 1234",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Manna Routh",
			// 		"StartDeadLine": "\/Date(1335436957423)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088",
			// 		"TaskDefinitionName": "Raise Purchase Request",
			// 		"TaskTitle": "Raise Purchase Request for Laptop",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Radhika Desai",
			// 		"StartDeadLine": "\/Date(1335523357193)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": true,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/87e65954364e805fa2343bc260978088",
			// 			"TaskName": "Raise Purchase Request",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f",
			// 		"TaskDefinitionName": "Some Dummy Task",
			// 		"TaskTitle": "Some Dummy Task for you",
			// 		"Priority": "LOW",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Utsav Banerjee",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/6ed97a4b707288c3ccc4c43c9fc1230f",
			// 			"TaskName": "Some Dummy Task",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b06f6964ab211e38aa90000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b06f6964ab211e38aa90000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0a19489ee1247c2b14111e1c23a005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F057a09e3e57fe3e71a361930cb5ef5a7",
			// 		"TaskDefinitionName": "Purchase Order Form",
			// 		"TaskTitle": "Purchase Order Form for iPad",
			// 		"Priority": "HIGH",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "",
			// 		"StartDeadLine": "\/Date(1335523354833)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": true,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F057a09e3e57fe3e71a361930cb5ef5a7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0a19489ee1247c2b14111e1c23a005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/057a09e3e57fe3e71a361930cb5ef5a7",
			// 			"TaskName": "Purchase Order Form",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3af69f944ab211e3826f0000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3af69f944ab211e3826f0000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0a19489ee1247c2b14111e1c23a005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F057a09e3e57fe3e71a361930cb5ef5a7",
			// 		"TaskDefinitionName": "Purchase Order Form",
			// 		"TaskTitle": "Purchase Order Form for iPad",
			// 		"Priority": "HIGH",
			// 		"Status": "READY",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Neelaja Panickar",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": true,
			// 		"SupportsClaim": true,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F057a09e3e57fe3e71a361930cb5ef5a7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0a19489ee1247c2b14111e1c23a005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/057a09e3e57fe3e71a361930cb5ef5a7",
			// 			"TaskName": "Purchase Order Form",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3ad8ac444ab211e385620000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3ad8ac444ab211e385620000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0faf6e82eece80fb14811e1a5a5005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2Ffd677a30fcc47ecbf323aa4543a2f815",
			// 		"TaskDefinitionName": "Sales Order Approval",
			// 		"TaskTitle": "Sales Order Approval - Laptops",
			// 		"Priority": "VERY_HIGH",
			// 		"Status": "READY",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": true,
			// 		"SupportsClaim": true,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2Ffd677a30fcc47ecbf323aa4543a2f815')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0faf6e82eece80fb14811e1a5a5005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/fd677a30fcc47ecbf323aa4543a2f815",
			// 			"TaskName": "Sales Order Approval",
			// 			"Category": "TASK"
			// 		}
			// 	}],
			// 	"__count": "7"
			// };

			// var jsonDataRefresh = {
			// 	"Tasks": [{
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review article",
			// 		"Priority": "MEDIUM",
			// 		"Status": "READY",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Vikrant Patil",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": true,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review and Approve article - 1234",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Manna Routh",
			// 		"StartDeadLine": "\/Date(1335436957423)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088",
			// 		"TaskDefinitionName": "Raise Purchase Request",
			// 		"TaskTitle": "Raise Purchase Request for Laptop",
			// 		"Priority": "MEDIUM",
			// 		"Status": "COMPLETED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Radhika Desai",
			// 		"StartDeadLine": "\/Date(1335523357193)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": false,
			// 		"SupportsComments": false,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/87e65954364e805fa2343bc260978088",
			// 			"TaskName": "Raise Purchase Request",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f",
			// 		"TaskDefinitionName": "Some Dummy Task",
			// 		"TaskTitle": "Some Dummy Task for you",
			// 		"Priority": "LOW",
			// 		"Status": "READY",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Utsav Banerjee",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": true,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/6ed97a4b707288c3ccc4c43c9fc1230f",
			// 			"TaskName": "Some Dummy Task",
			// 			"Category": "TASK"
			// 		}
			// 	}],
			// 	"__count": "4"
			// };

			// var jsonDataClaimed = {
			// 	"Tasks": [{
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F4cdae6754aca11e3abce0000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review article",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Vikrant Patil",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3fe0141d4aca11e395c80000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7",
			// 		"TaskDefinitionName": "Review and Approve article",
			// 		"TaskTitle": "Review and Approve article - 1234",
			// 		"Priority": "MEDIUM",
			// 		"Status": "RESERVED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Manna Routh",
			// 		"StartDeadLine": "\/Date(1335436957423)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": true,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F86666f9d2cfcbc5adcf55de85d11fed7')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe000054ca4e9d12f75a211e2ca8d0050569e0692",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/86666f9d2cfcbc5adcf55de85d11fed7",
			// 			"TaskName": "Review and Approve article",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b457d0a4ab211e3a4f50000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088",
			// 		"TaskDefinitionName": "Raise Purchase Request",
			// 		"TaskTitle": "Raise Purchase Request for Laptop",
			// 		"Priority": "MEDIUM",
			// 		"Status": "COMPLETED",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Radhika Desai",
			// 		"StartDeadLine": "\/Date(1335523357193)\/",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": false,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": false,
			// 		"SupportsComments": false,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F87e65954364e805fa2343bc260978088')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe098f47c713a0433b14711e1ac92005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/87e65954364e805fa2343bc260978088",
			// 			"TaskName": "Raise Purchase Request",
			// 			"Category": "TASK"
			// 		}
			// 	}, {
			// 		"__metadata": {
			// 			"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(InstanceID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2',SAP__Origin='LOCALHOST_C73_00')",
			// 			"type": "TASKPROCESSING.Task"
			// 		},
			// 		"SAP__Origin": "LOCALHOST_C73_00",
			// 		"InstanceID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-instance%2F3b1eee004ab211e3c6410000006379d2",
			// 		"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 		"TaskDefinitionID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f",
			// 		"TaskDefinitionName": "Some Dummy Task",
			// 		"TaskTitle": "Some Dummy Task for you",
			// 		"Priority": "LOW",
			// 		"Status": "READY",
			// 		"CreatedOn": "\/Date(1335439338973)\/",
			// 		"CreatedBy": "",
			// 		"CreatedByName": "Utsav Banerjee",
			// 		"StartDeadLine": "",
			// 		"CompletionDeadLine": "",
			// 		"ExpiryDate": "",
			// 		"LastChangedTime": "\/Date(1384328867199)\/",
			// 		"LastChangedBy": "",
			// 		"IsEscalated": false,
			// 		"SupportsClaim": true,
			// 		"SupportsRelease": false,
			// 		"SupportsForward": true,
			// 		"SupportsComments": true,
			// 		"HasComments": false,
			// 		"HasAttachments": false,
			// 		"HasPotentialOwners": false,
			// 		"IsSubstituted": false,
			// 		"SubstitutedUser": "",
			// 		"TaskDefinitionData": {
			// 			"__metadata": {
			// 				"uri": "http://mydemohost:50000/sap.com~tc~tm~wl~odata~web/BPMTasks.svc/TaskCollection(SAP__Origin='LOCALHOST_C73_00',TaskDefinitionID='bpm%3A%2F%2Fbpm.sap.com%2Ftask-definition%2F6ed97a4b707288c3ccc4c43c9fc1230f')",
			// 				"type": "TASKPROCESSING.Task"
			// 			},
			// 			"SAP__Origin": "LOCALHOST_C73_00",
			// 			"TaskModelID": "bpm%3A%2F%2Fbpm.sap.com%2Ftask-model%2Fe0f44551a7cce7a7b14811e1b644005056aa00d1",
			// 			"TaskDefinitionID": "bpm://bpm.sap.com/task-definition/6ed97a4b707288c3ccc4c43c9fc1230f",
			// 			"TaskName": "Some Dummy Task",
			// 			"Category": "TASK"
			// 		}
			// 	}],
			// 	"__count": "4"
			// };

			// var locale = 'en';
			// var inx = new sap.uiext.inbox.Inbox();
			// inx.setHandleBindings(false);
			// var taskFilter = new sap.uiext.inbox.TaskInitialFilters(["READY"], null, null, null); // (It is the Status, Priority filters as array)
			// var oModel = new sap.ui.model.json.JSONModel();
			// oModel.setData(jsonData);

			// inx.setModel(oModel);
			// inx.bindTaskTypeDynamicFilter(function() {
			// 	var t = [];
			// 	t.push('Raise Purchase Request');
			// 	t.push('Some Dummy Task');
			// 	t.push('Purchase Order Form');
			// 	t.push('LeaveReq');
			// 	return t;
			// })
			// inx.bindTaskTable("/Tasks", taskFilter);
			// inx.bindTaskExecutionURL(function(id) {
			// 	return "/demokit";
			// }, function(id) {
			// 	return "COMPLETED";
			// });
			// inx.bindSearch(function() {
			// 	alert('Not Supported');
			// });
			// inx.attachRefresh(function() {
			// 	oModel.setData(jsonDataRefresh);
			// });
			// inx.attachTaskAction(function(oEvent) {
			// 	alert(oEvent.getParameter('action'));
			// 	alert(oEvent.getParameter('selectedIDs'));
			// 	oModel.setData(jsonDataClaimed);
			// });
			// inx.placeAt('eqHistory');
		},

		onNavBack: function() {
			var sPreviousHash = History.getInstance().getPreviousHash(),
				oCrossAppNavigator;

			// if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation()) {
			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						shellHash: "#Shell-home"
					}
				});
			}
		}

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf ZBethyl.view.EquipmentHistory
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf ZBethyl.view.EquipmentHistory
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf ZBethyl.view.EquipmentHistory
		 */
		//	onExit: function() {
		//
		//	}

	});

});